package com.alqiri.legend

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

/** API key + model name, encrypted at rest with the Android Keystore. */
object SecureStore {
    @Volatile private var cached: SharedPreferences? = null

    private fun prefs(ctx: Context): SharedPreferences = cached ?: synchronized(this) {
        cached ?: run {
            val app = ctx.applicationContext
            val key = MasterKey.Builder(app).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build()
            EncryptedSharedPreferences.create(
                app, "alqiri_secure", key,
                EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
            )
        }.also { cached = it }
    }

    fun apiKey(ctx: Context): String = prefs(ctx).getString("api_key", "") ?: ""
    /** Blank = "automatic": the brain picks the default model of the detected provider. */
    fun model(ctx: Context): String = prefs(ctx).getString("model", "") ?: ""
    fun baseUrl(ctx: Context): String = prefs(ctx).getString("base_url", "") ?: ""

    fun save(ctx: Context, apiKey: String, model: String, baseUrl: String) {
        prefs(ctx).edit()
            .putString("api_key", apiKey)
            .putString("model", model)
            .putString("base_url", baseUrl)
            .apply()
    }

    fun saveModel(ctx: Context, model: String) {
        prefs(ctx).edit().putString("model", model).apply()
    }
}
